# poemarpy

## Description

A project by Aarón Montoya-Moraga.

## Installation

```bash
pip install poemar
```

## Use

Import Python module

```Python
import poemar
```

Functions

```Python
poemar.aleatoreizarMayusculas(texto)
```

## License

MIT
